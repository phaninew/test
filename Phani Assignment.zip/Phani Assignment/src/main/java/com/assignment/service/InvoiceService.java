package com.assignment.service;

import com.assignment.model.Invoice;
import com.assignment.repository.InvoiceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

@Service
public class InvoiceService {

    @Autowired
    InvoiceRepository invoiceRepository;

    public Invoice saveInvoice(Invoice invoice) {
        if(invoice.getLineItems().isEmpty()){throw new IllegalArgumentException("At least one item is required for invoice");}

        invoice.setSubTotal(calculateSubTotal(invoice));
        invoice.setVat(calculateVatRate(invoice));
        invoice.setTotal(calculateTotal(invoice));
        invoice.setInvoiceDate(new Date());
        return invoiceRepository.save(invoice);
    }

    private BigDecimal calculateSubTotal(Invoice invoice) {
        AtomicReference<BigDecimal> decimal = new AtomicReference<>(new BigDecimal(0));
        invoice.getLineItems().forEach(lineItem -> {
            decimal.set(decimal.get().add(lineItem.getLineItemTotal()));
        });
        return decimal.get().setScale(2, RoundingMode.HALF_UP);
    }

    private BigDecimal calculateVatRate(Invoice invoice) {
        BigDecimal result = calculateSubTotal(invoice).multiply(new BigDecimal(invoice.getVatRate())).divide(new BigDecimal(100));
        return result.setScale(2, RoundingMode.HALF_UP);
    }

    private BigDecimal calculateTotal(Invoice invoice) {
        AtomicReference<BigDecimal> total = new AtomicReference<>(new BigDecimal(0));
        invoice.getLineItems().forEach(lineItem -> {
            total.set(calculateSubTotal(invoice).add(calculateVatRate(invoice)));
        });
        return total.get().setScale(2, RoundingMode.HALF_UP);
    }

    public List<Invoice>  getAllInvoices(){
        return StreamSupport.stream(invoiceRepository.findAll().spliterator(), false)
                .collect(Collectors.toList());
    }

    public Invoice getInvoiceById(Long id){
        return invoiceRepository.findById(id) != null ? invoiceRepository.findById(id).get():null;
    }
}
