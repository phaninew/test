package com.assignment.controller;


import com.assignment.model.Invoice;
import com.assignment.service.InvoiceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


@RestController
public class InvoiceController {

    @Autowired
    InvoiceService invoiceService;

    @RequestMapping(value = "/viewAllInvoices")
    public List<Invoice> viewAllInvoices() {
       return invoiceService.getAllInvoices();
    }

    @RequestMapping(value = "/addInvoice")
    public Invoice addInvoice(@RequestBody Invoice invoice) {
        return invoiceService.saveInvoice(invoice);
    }

    @RequestMapping(value = "/viewInvoice/{invoiceId}")
    public Invoice viewInvoice(@PathVariable("invoiceId") Long id) {
        return invoiceService.getInvoiceById(id);
    }

}
