package com.assignment;

import com.assignment.model.LineItem;
import com.assignment.repository.LineItemRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@DataJpaTest
public class LineItemRepositoryTest {

    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private LineItemRepository lineItemeRepository;

    @Test
    public void testFindByLineItemId() {
        entityManager.persist(new LineItem(1L, "Sales", new BigDecimal(10.00)));
        LineItem lineItem = lineItemeRepository.findById(1L).get();
        assertEquals("Sales", lineItem.getDescription());
    }

}
